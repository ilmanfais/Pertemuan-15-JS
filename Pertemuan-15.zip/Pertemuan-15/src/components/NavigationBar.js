import React from "react"
import { Navbar, Container, Nav } from "react-bootstrap"

import "./NavigationBar.css"

const NavigationBar = () => {
  return (
    <div>
      <Navbar variant="light" className="navbar-custom">
        <Container>
          <Navbar.Brand href="/" className="navbar-brand-custom">
            PeTIK Jombang
          </Navbar.Brand>
          <Nav>
            <Nav.Link href="#ppl" className="nav-link-custom">
              PPL
            </Nav.Link>
            <Nav.Link href="#dm" className="nav-link-custom">
              DM
            </Nav.Link>
          </Nav>
        </Container>
      </Navbar>
    </div>
  )
}

export default NavigationBar;