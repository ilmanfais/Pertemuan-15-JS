import { Card, Container, Row, Col, Image } from "react-bootstrap"
import bowoImage from "../assets/images/dm/bowo.png"
import zakyImage from "../assets/images/dm/zaky.png"
import jalilImage from "../assets/images/dm/jalil.png"
import bayuImage from "../assets/images/dm/bayu.png"
import sultonImage from "../assets/images/dm/sulton.png"
import irwanImage from "../assets/images/dm/irwan.png"

const SuperHero = () => {
  return (
    <div>
      <Container>
        <br />
        <h1 className="text-white">Digital Marketing</h1>
        <br />
        <Row>
          <Col md={4} className="movieWrapper" id="dm">
            <Card className="movieImage">
              <Image src={bowoImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Bagus Harni Bowo</Card.Title>
                  <Card.Text className="text-center">
                  Sungai Baru Rt/Rw. 02/01 Sungai Baru Kec.Gaung Indragiri Hilir Riau 
                  </Card.Text>
                  <Card.Text className="text-center">
                  Digital Marketing
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={zakyImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">M. Zacky Ilham</Card.Title>
                  <Card.Text className="text-center">
                  Jl.Nasional Parit 3 Tembilahan Barat, Kel.Tembilaha, Kec Tembilahan Hulu Indragiri Hilir Riau
                  </Card.Text>
                  <Card.Text className="text-center">
                  Digital Marketing
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={jalilImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Muhammad Jalil </Card.Title>
                  <Card.Text className="text-center">
                  Jln. Parit Wak Gatak Komp Stivani 3 No.25 Kec.Sui Kakap Kubu Raya Kalimantan Bara
                  </Card.Text>
                  <Card.Text className="text-center">
                  Digital Marketing
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={bayuImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Bayu Saputra</Card.Title>
                  <Card.Text className="text-center">
                  Jl. Dusun V Aman Damai Rt/Rw:015/005, Kel. Harapan Maju, Kec, Sei Lepan Langkat Sumatera Utara
                  </Card.Text>
                  <Card.Text className="text-center">
                  Digital Marketing
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={sultonImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Sulthon Dai</Card.Title>
                  <Card.Text className="text-center">
                  Desa Pranggong Blok Waled Rt 013 Rw 004 Kec Arahan Indramayu Jawa Bara
                  </Card.Text>
                  <Card.Text className="text-center">
                  Digital Marketing
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={irwanImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Irwan Hadi</Card.Title>
                  <Card.Text className="text-center">
                  Jl. Jurusan Penanggak. Desa Persiapan Penanggak. Dusun Apit Aik Desa Persiapan Penanggak Kec. Batu Layar Lombok Barat NTB 
                  </Card.Text>
                  <Card.Text className="text-center">
                  Digital Marketing
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default SuperHero
