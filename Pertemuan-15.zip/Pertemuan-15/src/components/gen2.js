import React from "react";
import { Col, Container, Row, Button } from "react-bootstrap";
import "./Intro.css";

const Intro = () => {
  return (
    <div className="intro">
      <Container className="text-white text-center d-flex justify-content-center align-items-center">
        <Row>
          <Col>
            <div className="title">GEN - 2</div>
            <div className="title">PeTIK Jombang</div>
            <div className="introButton mt-4 text-center">
              <Button variant="dark">Lihat Semua Jurusan</Button>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default Intro;

