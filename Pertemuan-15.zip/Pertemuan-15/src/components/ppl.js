import { Card, Container, Row, Col, Image } from "react-bootstrap"
import aldiImage from "../assets/images/ppl/aldi.png"
import daniImage from "../assets/images/ppl/dani.png"
import ilmanImage from "../assets/images/ppl/ilman.jpg"
import hasanImage from "../assets/images/ppl/hasan.png"
import erikImage from "../assets/images/ppl/erik.png"
import nantoImage from "../assets/images/ppl/nanto.png"

const Trending = () => {
  return (
    <div>
      <Container>
        <br />
        <h1 className="text-white">Pengembangan Perangkat Lunak</h1>
        <br />
        <Row>
          <Col md={4} className="movieWrapper" id="ppl">
            <Card className="movieImage">
              <Image src={aldiImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Aldi Budiansah</Card.Title>
                  <Card.Text className="text-center">
                  Jl. Balai Desa Dusun Iv Rt 008, Payabenua, Kec. Mendo Barat, Bangka Bangka, Belitung
                  </Card.Text>
                  <Card.Text className="text-center">
                  Pengembangan Perangkat Lunak
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image
                src={daniImage}
                alt="Dune Movies"
                className="images"
              />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">
                  Rio Aditya Ramadhani
                  </Card.Title>
                  <Card.Text className="text-center">
                  Kp. Tengah, Kec. Kramat Jati, Jakarta Timur, DKI Jakarta
                  </Card.Text>
                  <Card.Text className="text-center">
                  Pengembangan Perangkat Lunak
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={ilmanImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">M. Fasrul Fais Ilman</Card.Title>
                  <Card.Text className="text-center">
                  Dusun Sawah Rt.04/Rw.02, Desa Sawah , Kec.Kampar Utara, Kampar, Riau 
                  </Card.Text>
                  <Card.Text className="text-center">
                  Pengembangan Perangkat Lunak
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={nantoImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Rusnanto</Card.Title>
                  <Card.Text className="text-center">
                  Jl. Kujang Jaya Blok Simpong Rt.008/Rw. 002, Kel. Panyingkiran Lor, Kec. Pantigi, Indramayu, Jawa Barat 
                  </Card.Text>
                  <Card.Text className="text-center">
                  Pengembangan Perangkat Lunak
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={hasanImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Hasan Mahmud</Card.Title>
                  <Card.Text className="text-center">
                  Jl.Namu Klumpang, No.47, Rt.04/Rw.02, Kel.Lae.Mbentar, Kec.Pagindar, Pakpak Bharat, Sumatera Utara
                  </Card.Text>
                  <Card.Text className="text-center">
                  Pengembangan Perangkat Lunak
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
          <Col md={4} className="movieWrapper">
            <Card className="movieImage">
              <Image src={erikImage} alt="Dune Movies" className="images" />
              <div className="bg-dark">
                <div className="p-2 m-1 text-white">
                  <Card.Title className="text-center">Erik Pratama</Card.Title>
                  <Card.Text className="text-center">
                  Epok Pangkalan Rt 008 /Rw 003 Dusun Sungai Jebung Desa Sungai Nibung Kec.Teluk Pakedai, Kubu Raya, Kalimantan Barat
                  </Card.Text>
                  <Card.Text className="text-center">
                  Pengembangan Perangkat Lunak
                  </Card.Text>
                </div>
              </div>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Trending
